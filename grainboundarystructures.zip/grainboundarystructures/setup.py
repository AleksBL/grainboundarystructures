from setuptools import setup
setup(name='grainboundarystructures',
      version='0.1',
      description='Module for keeping a repository of GB structures',
      url='',
      author='Aleksander Bach Lorentzen',
      author_email='abalo@dtu.dk',
      license='MIT',
      packages=['grainboundarystructures'],
      zip_safe=False)


