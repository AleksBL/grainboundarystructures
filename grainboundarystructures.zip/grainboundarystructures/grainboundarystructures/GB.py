import os
import sys
import sisl
sys.path.append(__file__[:-5]+'Files/')
print(__file__[:-5]+'Files/')
from GB1 import dev_A as GB1_Dev
from GB1 import EM_A  as GB1_EM
from GB1 import EP_A  as GB1_EP
def load_GB():
    from relaxed_GBs import structs
    return structs
def load_GB_SS():
    from relaxed_GB_SS import GBs
    return GBs
def load_GB_TS_relax():
    from relaxed_GB_TS import GBs
    return GBs


