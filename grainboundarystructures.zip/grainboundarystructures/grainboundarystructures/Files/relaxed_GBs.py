import numpy as np
import sisl
import matplotlib.pyplot as plt
import os
import sys
from ase import Atoms
import zipfile
    
fp = __file__[:-14]
sys.path.append(fp)
SD_1 = fp+'Relaxed_GBs.zip'
SD   = fp+'TmpDir/'
with zipfile.ZipFile(SD_1,"r") as zip_ref:
    zip_ref.extractall(SD)
SD += 'Relaxed_GBs/'

names   = os.listdir(SD)
names   = [n for n in names if 'failed' not in n]
names   = [n for n in names if 'collected_data' not in n]
names   = [n for n in names if len(os.listdir(SD+n))>19]

structs = {}

for i,n in enumerate(names):
    d = SD+n+'/'
    pd  = np.load(d+'pos_in_transiesta.npy')
    pem = np.load(d+'elec_m_pos_in.npy')
    pep = np.load(d+'elec_p_pos_in.npy')
    lat = np.load(d+'lat_in_transiesta.npy')
    cem = np.load(d+'cell_m_pos_in.npy')
    cep = np.load(d+'cell_p_pos_in.npy')

    dev = Atoms(positions = pd, 
                cell      = lat, 
                numbers   = 6 * np.ones(len(pd),dtype = int) )
    em = Atoms(positions  = pem, 
                cell      = cem, 
                numbers   = 6 * np.ones(len(pem),dtype = int) )
    ep = Atoms(positions  = pep, 
                cell      = cep, 
                numbers   = 6 * np.ones(len(pep),dtype = int) )
    
    dev = sisl.Geometry(xyz = dev.positions, atoms=dev.numbers, sc = dev.cell)#.fromASE(dev)
    em  = sisl.Geometry(xyz = em.positions, atoms=em.numbers, sc = em.cell)#.fromASE(em)
    ep  = sisl.Geometry(xyz = ep.positions, atoms=ep.numbers, sc = ep.cell)#.fromASE(ep)
    structs.update({i:[dev, em, ep, n]})

SD   += 'collected_data/'
names = os.listdir(SD)
names = [n for n in names if 'failed' not in n]
names = [n for n in names if 'collected_data' not in n]
names = [n for n in names if 'em' not in n]
names = [n for n in names if 'ep' not in n]
it    = i

for i,n in enumerate(names):
    dev = sisl.get_sile(SD + n).read_geometry()
    em  = sisl.get_sile(SD + n[:-10] + 'em.xyz').read_geometry()
    ep  = sisl.get_sile(SD + n[:-10] + 'ep.xyz').read_geometry()
    it+=1
    structs.update({it:[dev, em, ep, n]})

path = __file__[:-14]
os.system('rm -rf '+path+'TmpDir')

def find_new_pos(elec, dev, tol = 1e-2):
    newr     =  elec.xyz.copy()
    r        =  elec.xyz
    dr       =  dev.xyz
    R0,R1    =  dev.cell[[0,1]]
    T        =  []
    for i in range(1):
        for j in range(-5,6):
            T+=[(i,j)]
    
    for i,ri in enumerate(r):
        dij = np.linalg.norm(ri - dr,axis = 1)
        if (dij<tol).any():
            pass
        else:
            for t in T:
                Tv  = R0 * t[0]+ R1 * t[1]
                dij = np.linalg.norm(ri+Tv -dr, axis = 1)
                if (dij<tol).any():
                    newr[i] = ri + Tv
                    break
    new_elec = Atoms(positions = newr, cell = elec.cell, numbers = elec.atoms.Z.copy())
    new_elec = sisl.Geometry.fromASE(new_elec)
    return new_elec

def fix_setup(dev,em,ep):
    xyz = dev.xyz.copy()
    cell = dev.cell.copy()
    s = dev.to.ase().numbers.copy()
    if cell[0,0]<0:
        cell[0]*=-1
    _D = Atoms(positions = xyz, cell = cell, numbers = s)
    _D = sisl.Geometry.fromASE(_D)
    xmin = -_D.xyz[:,0].min()
    _D = _D.move([xmin,0,0])
    em = em.move([xmin,0,0])
    ep = ep.move([xmin,0,0])
    _D=_D.to.ase()
    _D.wrap(pbc = True)
    _D = sisl.Geometry.fromASE(_D)
    em = find_new_pos(em,_D)
    ep = find_new_pos(ep,_D)
    
    return _D,em,ep

for v in structs.keys():
    d,em,ep,n = structs[v]
    #d,em,ep = fix_setup(d,em,ep)
    structs[v] = [d, em, ep, n]
