geometries for the 2019 Paper removing all periodic boundary conditions, Papior, Leitherer, Calgero, Brandbyge

