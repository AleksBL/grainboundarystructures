import numpy as np
import sisl
import sys
import os

fp = __file__[:-16]
sys.path.append(fp)
SD      = fp+'SanSebastian_GBs'
names   = os.listdir(SD)
#print(names)
GBs = []

for n in names:
    dic = {'EM':sisl.get_sile(SD+'/'+n+'/EM.xyz').read_geometry(),
           'EP':sisl.get_sile(SD+'/'+n+'/EP.xyz').read_geometry(),
           'D':sisl.get_sile(SD+'/'+n+'/D.xyz').read_geometry(),
           'v':np.load(SD+'/'+n+'/v.npy'),
           'name':n
           }
    GBs += [dic]
