import numpy as np
import sisl
import sys
import os

fp = __file__[:-16]
sys.path.append(fp)
SD      = fp+'TSRelaxedGB/folder1'
names   = sorted(os.listdir(SD))
GBs     = []


for n in names:
    files = os.listdir(SD+'/'+n)
    if 'SkipThis.npy' in files:
        print('Skipped ', n)
        continue
    
    dic = {'EM':sisl.get_sile(SD+'/'+n+'/em.xyz').read_geometry(),
           'EP':sisl.get_sile(SD+'/'+n+'/ep.xyz').read_geometry(),
           'D':sisl.get_sile(SD+'/'+n+'/device.xyz').read_geometry(),
           'name':'folder1_'+n
           }
    
    GBs += [dic]

SD      = fp+'TSRelaxedGB/folder2'
names   = sorted(os.listdir(SD))
for n in names:
    files = os.listdir(SD+'/'+n)
    if 'SkipThis.npy' in files:
        print('Skipped ', n)
        continue
    dic = {'EM':sisl.get_sile(SD+'/'+n+'/em.xyz').read_geometry(),
           'EP':sisl.get_sile(SD+'/'+n+'/ep.xyz').read_geometry(),
           'D':sisl.get_sile(SD+'/'+n+'/device.xyz').read_geometry(),
           'name':'folder2_'+n
           }
    GBs += [dic]
