import numpy as np
from ase import Atoms
import sisl
import os
import sys
fp = __file__[:-6]
sys.path.append(fp)
cem = np.load(fp+'GB1_files/GB1_cem.npy')
cep = np.load(fp+'GB1_files/GB1_cep.npy')
lat = np.load(fp+'GB1_files/GB1_lattice.npy')
pbm = np.load(fp+'GB1_files/GB1_pbm.npy')
pbp = np.load(fp+'GB1_files/GB1_pbp.npy')
pd  = np.load(fp+'GB1_files/GB1_pd.npy')
pem = np.load(fp+'GB1_files/GB1_pem.npy')
pep = np.load(fp+'GB1_files/GB1_pep.npy')

y2 = 25.7559/2 + 0.7
y1 = 4.8
x2 = 14.5
x1 = 45

pcut       = pd[(pd[:,1]<y2)*(pd[:,1]>y1)]
off_y      = pcut[:,1].min()
pcut[:,1] -= off_y

c = sisl.geom.graphene(orthogonal = True).cell[0,:]
lat = np.diag([lat[0,0], 2 * 4.26, 12.3])
pcut = pcut[(pcut[:,0]<x1 )*(pcut[:,0]>x2)]

cem = cem[[1,0,2]]
cep = cep[[1,0,2]]
cep[0,0]*=-1

pem = pem[(pem[:,1]<y2)*(pem[:,1]>y1)]
pep = pep[(pep[:,1]<y2)*(pep[:,1]>y1)]

R1 = pcut[0] - pem[7]
R2 = pcut[-4]- pep[0]
pem = pem + R1
pep = pep + R2

for i in range(len(pcut)):
    for j in range(len(pem)):
        if np.linalg.norm(pcut[i] - pem[j])<0.3:
            pcut[i] = pem[j]
    for j in range(len(pep)):
        if np.linalg.norm(pcut[i] - pep[j])<0.3:
            pcut[i] = pep[j]
def fromASE(A):
    try:
        return sisl.Geometry(xyz=A.positions, sc =A.cell, atoms=A.numbers)
    except:
        return sisl.Geometry(xyz=A.positions, lattice =A.cell, atoms=A.numbers)


dev_A = fromASE(Atoms(positions = pcut, numbers=6 * np.ones(len(pcut)), cell = lat))
EM_A  = fromASE(Atoms(positions = pem , numbers=6 * np.ones(len(pem)) , cell = cem))
EP_A  = fromASE(Atoms(positions = pep , numbers=6 * np.ones(len(pep)) , cell = cep))

# EM = SiP(EM_A.cell, EM_A.xyz, EM_A.toASE().numbers)
# EP = SiP(EP_A.cell, EP_A.xyz, EP_A.toASE().numbers)
# Dev = SiP(dev_A.cell, dev_A.xyz, dev_A.toASE().numbers, elecs = [EM,EP])
# Dev.find_elec_inds()

# dev_A = Dev.to_sisl()

