#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Apr  7 20:24:31 2021

@author: aleks
"""
from GrainBoundaryModule.GrainB2 import RANDOM_SEARCH, GrainBoundary, build_and_plot, Angle_Check, distance_ij, NNR_2
from siesta_python.siesta_python import SiP
from siesta_python.funcs import numpy_inds_to_string, listinds_to_string, get_random_from_LM2, recreate_old_calculation,subgroups, read_fat
from GrainBoundaryModule.GrainBoundaryFunctions import name_and_path, get_cell, initial_guess_loop
import numpy as np
import os
import matplotlib.pyplot as plt
from tqdm import tqdm
from datetime import datetime
from time import sleep
import sisl

def SC(p): plt.scatter(p[:,0],p[:,1])

mpi = 'mpirun '
BASIS='SZ'
ke=[100,25,1]; kd=[1,25,1]; kt=[1,800,1]; mc=150
kp_bands = [3,7,1]

#Run c0nfig
nds        = 10
nss        = 20
dn         =  2
relax_pm   = 5.5
mw         = 70
Max_len_GB = 12
frac = 1.42930 / 1.42028166 # from a_lat = 2.46 to relaxed lattice constant
force_tol = 1e-2
electrode_min_size = 10
take_from_LM2      = False
spin_pol           = 'non-polarised'

Normal_run = True
ReRun      = False
ReRun_tag  = 'device'
if ReRun:      assert Normal_run == False
if Normal_run: assert ReRun == False

done_list = []
Vs = [0.0, 0.01, 0.05, 0.1]
Pot_BP = 0.1
thickness_BP = 2.5

#Move GB-back and fourth in x-direction in nds steps
#Move GB-back and fourth in y-direction in nss steps
D      =  np.linspace(-0.2,0.5,nds)
shift  = np.linspace(-0.2,0.2,nss)

n_tests = 10000
siesta_count = 0
siesta_max = 100
vacuum = 5
sep_tol = 0.3

def find_idx_electrode(pe, other_pos, V_GB):
    pe_new = np.zeros(pe.shape)
    idx = []
    norm = np.linalg.norm
    for ii, ri in enumerate(pe):
        it=0
        for rj in other_pos:
            if norm(ri - rj)<sep_tol:
                idx += [it]
                pe_new[ii] = ri
            if norm(ri - rj + V_GB)<sep_tol:
                idx+=[it]
                pe_new[ii,:] = ri + V_GB
                
            if norm(ri-rj - V_GB)<sep_tol:
                idx+=[it]
                pe_new[ii,:] = ri - V_GB
                
            it+=1
    return idx,pe_new

# num = (-4,  3, -4,  1, -1,  4,  0, -3)
# v = [4.67391795, 1.]
# cA,A,cB,X,V_GB = build_and_plot(6.13983773, 1.01036297,-3, -5, 0, 3, -4, -4, -3, 1)
# cA,A,cB,X,V_GB = build_and_plot(5.90293409, 1.00000003,1, 2, -5, 5, -3, 6, 2, 1)
# cA,A,cB,X,V_GB = build_and_plot(1.71414387, 1.00000002,-2, 1, 1, 2, -1, 2, -3, 2)
# cA,A,cB,X,V_GB = build_and_plot(1.42744877, 1.00000002,3, -2, -3, -1, 1, 2, 2, -3)

def DFT_Relaxation(Test, pass_through = False, vals = None):
    #DFT relaxation
    # pos_in are the initial positions from gulp, but made to "bite its own tail"
    # T is the resulting other lattice vector of the structure, the first being V_GB
    # n0 is the indices of the atoms we are interested in and n1 are the ones inserted to bite its own tail
    # i_dyn are is one for the atoms which should be able to move during relaxation
    
    if pass_through == True:
        return vals
    
    pos_in, T, x_gb1, x_gb2 = Test.flip_and_stack_gulp()
    relax_t = 6 * np.ones(len(pos_in))
    relax_cell = np.array([[abs(T[0]) + 10, 0, 0],[0, V_GB[1], 0], [0,0,12.3]])
    
    # sort the regions that should move rigidly.
    idx_m1 = np.where( pos_in[:, 0] < x_gb1 - relax_pm)[0]
    idx_m2 = np.where( pos_in[:, 0] > x_gb1 + relax_pm + df)[0]
    all_idx= set(np.arange(len(pos_in)))
    
    idx_gb = np.array([æ for æ in (all_idx - set(idx_m1) - set(idx_m2) ) ])
    pos_in[idx_gb,2] += 0.01 *  np.random.random(len(idx_gb))
    
    C1 = 'rigid ' + listinds_to_string(numpy_inds_to_string(idx_m1+1))  + ' 1. 1. 1.'
    C2 = 'rigid ' + listinds_to_string(numpy_inds_to_string(idx_m2+1))  + ' 0. 0. 1.'
    
    sleep(0.5)
    Constraints = [C1, C2]
    
    DFT_RELAX_SZ=SiP(
                     relax_cell,pos_in,relax_t,
                     directory_name='SZ_Relax_'+name,
                     kp = kp_bands,mesh_cutoff=mc,
                     mpi = mpi,
                     basis='SZ',
                     pp_path = 'pp',
                     
                     calc_bands=False,
                     overwrite=True,
                     Standardize_cell=False,
                     print_console = False,
                    )
    
    DFT_RELAX_SZ.fdf_relax(Constraints, force_tol = force_tol)
    print('Twist-angle: ', np.degrees(v[0]), '\n')
    DFT_RELAX_SZ.run_siesta_in_dir()
    DFT_RELAX_SZ.read_relax()
    DFT_RELAX_SZ.relaxed_pos = np.hstack((pos_in, np.array([relax_t]).T))
    DFT_RELAX_SZ.relaxed_lat = relax_cell
    return DFT_RELAX_SZ, idx_m1,idx_m2,pos_in,T

def do_stuff_1(object):
    object.find_elec_inds(tol = 1e-2)
    object.fdf(eta = 0.0)
    object.write_more_fdf(['TS.Hartree.Fix -A\n'],
                          name='TS_TBT')
    object.write_more_fdf(['%block TS.kgrid.MonkhorstPack\n',
                           '     '+str(1)      + '   0   0 \n',
                           '     0    ' + str(ke[1])+ '  0 \n',
                           '     0    0    ' +        str(1)+' \n',
                           '%endblock TS.kgrid.MonkhorstPack\n'], name='KP')

def do_stuff_2(object):
    object.run_analyze_in_dir()
    object.run_siesta_in_dir()
    object.run_tbtrans_in_dir(DOS_GF = True)

def Do_Stuff(object):
    do_stuff_1(object)
    do_stuff_2(object)

def d_proj_v(A, v):
    return (A*(v/np.linalg.norm(v))).sum(axis=1)

def save_data_1(path):
    np.save(path+'/'+'relaxed_pos',pos)
    np.save(path+'/'+'CA',Test.CA)
    np.save(path+'/'+'CB',Test.CB)
    np.save(path+'/'+'V_GB',Test.V_GB)
    np.save(path+'/'+'Avec',Test.A)
    np.save(path+'/'+'Bvec',Test.B)
    np.save(path+'/'+'num',num)
    np.save(path+'/'+'v',v)
    np.save(path+'/'+'d_shift',ds_save)
    np.save(path+'/'+'raw_gulp_lat',Test.Calc.gulp_results[1])
    np.save(path+'/'+'raw_gulp_pos',Test.Calc.gulp_results[0])

def save_data_2(path):
    np.save(path + '/' + 'pos_in_transiesta',     pn     )
    np.save(path + '/' + 'lat_in_transiesta',     lattice)
    np.save(path + '/' + 'species_in_transiesta', an     )
    
    np.save(path + '/' + 'elec_m_pos_in',         pem    )
    np.save(path + '/' + 'cell_m_pos_in',         cem    )
    np.save(path + '/' + 'species_m_pos_in',      tem    )
    
    np.save(path + '/' + 'elec_p_pos_in',         pep    )
    np.save(path + '/' + 'cell_p_pos_in',         cep    )
    np.save(path + '/' + 'species_p_pos_in',      tep    )

def make_dir(path):
    try:
        os.makedirs(path)
    except FileExistsError:
        pass

def make_electrode(name, p, c, t, PM, direc, Chem_Pot = 0.0):
    elec = SiP(c,p,t,
               spin_pol = spin_pol,
               TwoDim=True, kp=ke,
               directory_name=PM+name,
               sl  = PM,
               mpi = mpi,
               dm_tol  = '1.d-6',
               pp_path = 'pp',
               sm=PM,
               #Chem_Pot = Chem_Pot,
               basis=BASIS,
               semi_inf = direc,max_scf_it =200,
               print_console=False,k_shift=0,mesh_cutoff=mc,
               overwrite=True,
               mixer='Pulay',
               n_hist=8
               )
    
    return elec

def make_device(name, p, c, t, elecs, idx_buffer, 
                Chem_Pots = [0.0, 0.0], Voltage = 0.0, 
                elec_inds = None, tol_elec_pos = 1e-5, NEGF = False, reuse_dm = False):
    
    if elec_inds is None:
        elec_inds = [[] for i in range(len(elecs))]
        it_e = 0
        for e in elecs:
            for x in e.pos_real_space:
                d =  ( ((p-x)**2).sum(axis = 1) ) ** 0.5
                inds = np.where(d < tol_elec_pos)[0]
                if len(inds)> 0:
                    elec_inds[it_e]+= [inds[0]]
            it_e+=1
    
    it_e = 0
    for e in elecs:
        x = e.pos_real_space
        if len(x) != len(elec_inds[it_e]):
            print('different number of atoms in elec inds compared to elecs')
    
    if len(Chem_Pots) != len(elecs):
        print('specify all Chemical potentials of electodes')
        assert 1 == 0
    
    Dev = SiP(c, p, t,
              spin_pol = spin_pol,
              kp = kd, solution_method='transiesta',
              elecs = elecs, max_scf_it=250,
              pp_path = 'pp',
              mpi = mpi,
              basis = BASIS,
              directory_name='device_'+name,
              kp_tbtrans=kt, mesh_cutoff=mc,
              trans_emin=-0.5,trans_emax=0.5,
              trans_delta=0.01,Chem_Pot=Chem_Pots,
              overwrite=True,
              NEGF_calc = NEGF,
              reuse_dm = reuse_dm
             )
    return Dev

def make_bandcalc(name, p,c,t):
    Calc = SiP(c, p, t, directory_name = 'BandCalc_'+name,
             kp = kp_bands, basis = BASIS,
             overwrite = True, Bands_plot = True,
             calc_bands = True,
             mpi = mpi,
            )
    
    Calc.fdf()
    Calc.fatband_fdf()
    Calc.custom_bandlines(['1 0.0 0.0 0.0 \Gamma\n' , 
                           '25 0.0 0.5 0.0 M\n'     ,
                           '25 0.5 0.5 0.0,X\n'     ,
                           '25 0.0 0.0 0.0 \Gamma\n',
                           '25 0.5 0.0 0.0 Y\n'      ])
    return Calc

while Normal_run:
    name, path = name_and_path()
    
    cA,A,cB,X,V_GB, num, v = get_cell('Trimmed', Max_len_GB = 15)
    
    # cA,A,cB,X,V_GB  = build_and_plot(2.57952285, 1., -4,  1, -1, -3,  3,  1, -4,  2, sensible_cells=True)#
    # num = (-4,  1, -1, -3,  3,  1, -4,  2)
    # v   = (2.57952285, 1.)
    # cA  *= frac; cB  *= frac
    # A   *= frac; X   *= frac
    # V_GB*= frac
    Test, ds_save = initial_guess_loop(cA, A, cB, X, V_GB, D, shift, mw, dn)
    df = ds_save[0]
    if  isinstance(Test.gulp_pos_out,str):
        print('failed: UC wrap failed somewhere')
    else:
        pos = Test.gulp_pos_out.copy()
        # The last na+nb indecies are atoms in the leads
        pos_gb = pos[0:len(pos)-len(Test.CA)-len(Test.CB)]
        dij = distance_ij(pos_gb, 
                          pos, 
                          Test.V_GB, 
                          len(Test.CA))
        # vectors going from the i'th carbon atom to the twelve (can be altered in GrainB2)
        # nearest neighbors
        nnr = NNR_2(dij, pos_gb,pos, Test.V_GB)
        Counts = Angle_Check(nnr,min_angle = 100, max_angle = 160)
        if Counts < 3:
            make_dir(path)
            save_data_1(path)
            print('Succes')
            
            DFT_RELAX_SZ, idx_m1, idx_m2, pos_in, T = DFT_Relaxation(Test)
            r_pos = DFT_RELAX_SZ.relaxed_pos.copy()
            t = r_pos[:,3].copy()
            r_pos = r_pos[:,0:3]
            r_lat = DFT_RELAX_SZ.relaxed_lat.copy()
            
            m2_cent_T = np.average(r_pos[idx_m2][:,[0, 1]],axis = 0) - np.average(pos_in[idx_m2][:,[0, 1]], axis = 0)
            m2_cent_T = np.hstack((m2_cent_T, np.zeros(1)))
            pem = Test.CA -  Test.A *(Test.stack_it_v-1)
            
            ø = 2
            while d_proj_v(pem, -Test.A ).max()-d_proj_v(pem, -Test.A ).min() < electrode_min_size:
                pem = np.vstack((pem, Test.CA - Test.A*(Test.stack_it_v - ø)))
                ø +=1
            num_uc_v = ø-1
            
            pep = Test.CB +  Test.B *(Test.stack_it_h-1)
            ø   = 2
            while d_proj_v(pep, Test.B ).max()-d_proj_v(pep, Test.B ).min() < electrode_min_size:
                pep = np.vstack(( Test.CB + Test.B*(Test.stack_it_h - ø), pep ))
                ø +=1
            num_uc_h = ø-1
            
            pep = pep + m2_cent_T
            T   = T   + m2_cent_T
            delta_z_m1 = np.average(r_pos[idx_m1,2]) - np.average(pos_in[idx_m1,2])
            delta_z_m2 = np.average(r_pos[idx_m2,2]) - np.average(pos_in[idx_m2,2])
            pem[:,2]+=delta_z_m1
            pep[:,2]+=delta_z_m2
            ####
            idx_em, pem  = find_idx_electrode(pem, r_pos, Test.V_GB)
            idx_ep, pep  = find_idx_electrode(pep, r_pos, Test.V_GB)
            
            if len(idx_em) != len(pem) or len(idx_ep) != len(pep):
                np.save(path+'/'+'elec_matching_failed_pem',pem)
                np.save(path+'/'+'elec_matching_failed_pep',pep)
                np.save(path+'/'+'elec_matching_failed_r_pos',r_pos)
            else:
                r_pos[idx_em,:] = pem[:,:]
                r_pos[idx_ep,:] = pep[:,:]
                
                C_v = d_proj_v(pem, - A).sum()/len(pem)
                C_h = d_proj_v(pep, + X).sum()/len(pep)
                idx_buffer_v = np.where(d_proj_v(r_pos, - A) > C_v )[0]; 
                idx_buffer_v = np.array(list( set(idx_buffer_v) - set(idx_em) ))
                idx_buffer_h = np.where(d_proj_v(r_pos, + X) > C_h )[0]
                idx_buffer_h = np.array(list( set(idx_buffer_h) - set(idx_ep) ))
                idx_buffer = np.hstack((idx_buffer_h, idx_buffer_v)).astype(int)
                
                print('electrodes repeated ', ø-1 , ' times\n')
                plt.pause(1)
                
                # - x direction electrode atomic types and cell 
                tem = 6*np.ones(len(pem))
                cem = np.array([Test.A*num_uc_v,
                                Test.V_GB,
                                [0,0,12.3]]).round(6)
                
                #......
                tep = 6*np.ones(len(pep))
                cep = np.array([Test.B*num_uc_h,
                                Test.V_GB,
                                [0,0,12.3]]).round(6)
                
                #Calculation for bandstructure
                BandPos_idx                 = np.array(list(set(np.arange(len(r_pos)) ) - set(idx_buffer)))
                BandPos                     = r_pos[BandPos_idx]
                Band_GB_object              = GrainBoundary(cA, A, cB, X, V_GB)
                Band_GB_object.gulp_pos_out = BandPos
                Band_GB_object.dynamic_x    = Test.dynamic_x
                BandPos, T, tr_a, tr_aa     = Band_GB_object.flip_and_stack_gulp()
                BandCalc = make_bandcalc(name, BandPos, np.array([T, V_GB, [0,0,15.0,]]),6*np.ones(len(BandPos)).astype(int))
                BandCalc.run_siesta_in_dir()
                
                xyz = BandCalc.pos_real_space
                l1 = list(np.where(np.abs(xyz[:,0])<5.0)[0]+1)
                l2 = list(np.where(np.abs(xyz[:,0])>=5.0)[0]+1)
                proj = {'g1': l1,
                        'g2': l2, 
                        }

                proj  =  subgroups(proj)
                BandCalc.run_fatbands(proj)
                b, R  =  read_fat(BandCalc.dir)
                #BC_ef = sisl.get_sile(BandCalc.dir+'/RUN.out').read_energy()['fermi']
                #if 'g1' in b[0]:
                #    plt.scatter(R[0][0][:,0],R[0][0][:,1],s = 3*R[0][1]/R[1][1])
                #else:
                #    plt.scatter(R[1][0][:,0],R[1][0][:,1],s = 3*R[1][1]/R[0][1])
                #plt.hlines(BC_ef, 0,1, linestyles = 'dashed')
                #plt.ylim( [-1.5+BC_ef, +1.5+BC_ef])
                #plt.xlim([R[0][0][:,0].min(), R[0][0][:,0].max()])
                #plt.savefig(BandCalc.dir+'/WeightedBands.png',dpi = 300)
                os.system('rm '+BandCalc.dir+'/siesta.WFSX')
                os.system('rm '+BandCalc.dir+'/siesta.fullBZ.WFSX')
                #Lav fdf filer og beregn
                #######################
                elecs = [make_electrode(name, pem, cem, 
                                        tem,'ELEC_M_','-a1'),
                         make_electrode(name, pep, cep, 
                                        tep,'ELEC_P_','+a1')
                        ]
                
                for elec in elecs:
                    elec.fdf(eta = 0.0); 
                    elec.set_parallel_k(); 
                    elec.run_siesta_electrode_in_dir()
                
                lattice = np.array([T, V_GB, [0,0,12.3]])
                pn = r_pos.copy()
                an = DFT_RELAX_SZ.s
                save_data_2(path)
                
                # device region DFT calculation
                GB_DFT = make_device(name, pn, lattice, an, elecs, idx_buffer)
                GB_DFT.find_elec_inds(tol = 1e-2)
                
                
                
                def buffer_condition(r):
                    R = r.copy()
                    if d_proj_v(np.array([R]), - A).sum() > C_v and (np.linalg.norm(r-elecs[0].pos_real_space,axis = 1)>1e-2).all():
                        return True
                    if d_proj_v(np.array([R]), + X).sum() > C_h and (np.linalg.norm(r-elecs[1].pos_real_space,axis = 1)>1e-2).all():
                        return True
                    return False
                
                GB_DFT.set_buffer_atoms(buffer_condition)
                assert len(GB_DFT.elec_inds[0]) == len(pem)
                assert len(GB_DFT.elec_inds[1]) == len(pep)
                
                #Do_Stuff(GB_DFT)
                
                
                ####### NEGF #######
                # Calcs  = []
                # Volts = []
                # for V in Vs:
                #     if V  == 0:
                #       Calcs += [make_device(name + 'bias_' + str(np.round(V,4)), 
                #                            pn, lattice, an, elecs, idx_buffer, 
                #                            elec_inds = elec_inds, 
                #                            NEGF = True, Voltage = V, 
                #                            Chem_Pots = [-V/2, V/2])]
                #       Volts = [V]
                #     else:
                #         for s in [-1,1]:
                #             if s==1:
                #                 ss = 'plus_'
                #             elif s == -1:
                #                 ss = 'minus_'
                #             Calcs += [make_device(name + 'bias_'+ ss + str(np.round(V,4)), 
                #                                   pn, lattice, an, elecs, idx_buffer, 
                #                                   elec_inds = elec_inds, 
                #                                   NEGF = True, reuse_dm = True, Voltage = V, 
                #                                   Chem_Pots = [-s * V/2, s * V/2])          ]
                #             Volts+=[s*V]
                
                # Calculated = np.full(len(Volts), np.nan)
                # Calculated[0] = 0.
                # Do_Stuff(Calcs[0])
                
                # for count in range(1,len(Volts)):
                #     v       = Volts[count]
                #     absdiff = np.abs(Calculated - v)
                #     absdiff[np.where(np.isnan(absdiff))] = 10**9
                #     idx = np.where(absdiff == absdiff.min())[0][0]
                #     Calcs[count].copy_DM_from(Calcs[idx])
                #     Do_Stuff(Calcs[count])
                
                # LL = np.array([lattice[0,:],
                #                lattice[1,:],
                #                [0,0,25.0]
                #               ])
                
                # a = [0. , V_GB[1]/1.0, 0.   ]
                # b = [0. , 20.0,      0.   ]
                # o = [0. , b[1]/2.,  25./2.]
                
                # A = make_device(name + 'plus_BP', pn, LL, an, elecs, idx_buffer)
                # do_stuff_1(A)
                # A.Add_Bounded_Plane(o, a, b, Pot_BP, thickness_BP)
                # do_stuff_2(A)
                
                # B = make_device(name + 'minus_BP', pn, LL, an, elecs, idx_buffer)
                # do_stuff_1(B)
                # B.Add_Bounded_Plane(o, a, b, -Pot_BP, thickness_BP)
                # do_stuff_2(B)
                
                # slut fdffiler og beregn
                #################################
                
        else:
            path = path+'_failed'
            
            make_dir(path)
            save_data_1(path)
            print('failed: some angles were too large')
    
def ReRun_Directory_Simple(Do_this_also  = None):
    _files = os.listdir()
    files = os.listdir()
    
    files = [i for i in files
             if ReRun_tag    in i
             and 'plus'  not in i
             and 'minus' not in i
             and 'bias'  not in i
             and 'redo'  not in i]
    
    for f in files:
        d, e = recreate_old_calculation(f)
        name, path = name_and_path()
        it = 1
        while f + '_redone_' + str(it) in _files:
            it+=1
        
        name = f + '_redone_' + str(it)
        
        redo_em = make_electrode(name, e[0][0][:,0:3], e[0][1], e[0][0][:,3], 'EM', '-a1')
        redo_ep = make_electrode(name, e[1][0][:,0:3], e[1][1], e[1][0][:,3], 'EP', '+a1')
        redo_em.fdf(); redo_em.run_siesta_electrode_in_dir()
        redo_ep.fdf(); redo_ep.run_siesta_electrode_in_dir()
        
        device_redo = make_device(name, d[0], d[1], d[2], [redo_em, redo_ep], d[3] )
        do_stuff_1(device_redo)
        if Do_this_also is not None:
            Do_this_also(device_redo)
        do_stuff_2(device_redo)


if ReRun:
    ReRun_Directory_Simple()





